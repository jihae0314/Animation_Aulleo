package com.board.model;

public class ApplicationDto {

	int boa_app_no;
	String boa_app_date;    
	String boa_app_contents;
	String boa_app_state;
	int boa_no;
	int mem_no;
	String app_file;
	String mem_email;
	String mem_nickname;
	String mem_job;
	String mem_icon;
	
	
	public int getBoa_app_no() {
		return boa_app_no;
	}
	public void setBoa_app_no(int boa_app_no) {
		this.boa_app_no = boa_app_no;
	}
	public String getBoa_app_date() {
		return boa_app_date;
	}
	public void setBoa_app_date(String boa_app_date) {
		this.boa_app_date = boa_app_date;
	}
	public String getBoa_app_contents() {
		return boa_app_contents;
	}
	public void setBoa_app_contents(String boa_app_contents) {
		this.boa_app_contents = boa_app_contents;
	}
	public String getBoa_app_state() {
		return boa_app_state;
	}
	public void setBoa_app_state(String boa_app_state) {
		this.boa_app_state = boa_app_state;
	}
	public int getBoa_no() {
		return boa_no;
	}
	public void setBoa_no(int boa_no) {
		this.boa_no = boa_no;
	}
	public int getMem_no() {
		return mem_no;
	}
	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}
	public String getApp_file() {
		return app_file;
	}
	public void setApp_file(String app_file) {
		this.app_file = app_file;
	}
	public String getMem_email() {
		return mem_email;
	}
	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}
	public String getMem_nickname() {
		return mem_nickname;
	}
	public void setMem_nickname(String mem_nickname) {
		this.mem_nickname = mem_nickname;
	}
	public String getMem_job() {
		return mem_job;
	}
	public void setMem_job(String mem_job) {
		this.mem_job = mem_job;
	}
	public String getMem_icon() {
		return mem_icon;
	}
	public void setMem_icon(String mem_icon) {
		this.mem_icon = mem_icon;
	}
}
